from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import numpy as np

app = FastAPI()

# Carregar o modelo
model = joblib.load('/fast_api_cm/modelo_diabetes.pkl')

# Definindo o modelo de entrada para as características
class Features(BaseModel):
    preg_count: int
    glucose: float
    blood_pressure: float
    skin_thickness: float
    insulin: float
    bmi: float
    diabetes_pedigree: float
    age: int

@app.get("/api/health")
def health():
    return {"status": "Estou saudável"}

@app.post("/api/predict")
def predict(features: Features):
    features_array = np.array([[
        features.preg_count,
        features.glucose,
        features.blood_pressure,
        features.skin_thickness,
        features.insulin,
        features.bmi,
        features.diabetes_pedigree,
        features.age
    ]])
    prediction = model.predict(features_array)
    return {"prediction": int(prediction[0])}
